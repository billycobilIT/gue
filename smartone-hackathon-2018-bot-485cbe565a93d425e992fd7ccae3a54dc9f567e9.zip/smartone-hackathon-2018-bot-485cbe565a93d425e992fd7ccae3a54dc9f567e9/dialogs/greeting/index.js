// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { GreetingDialog } = require('./greeting');

exports.GreetingDialog = GreetingDialog;
